/**
 * Public vocabulary shared by the Host service, the Remote surface and the client UI.
 *
 * Every type here crosses the Remote boundary, so it stays inside the JSON subset the
 * Typert generator can project: scalars, readonly arrays, string-literal unions, and
 * nullable fields. No Dates, class instances, or dictionaries with unknown values.
 * @module dsh-voice-input
 */
/** Package identity used by the Loader patch, the Remote namespace and the client bundle. */
export declare const PACKAGE_NAME = "dsh-voice-input";
/** Loader entry id declared by this bundle's patch. */
export declare const BUNDLE_ENTRY_ID = "voice-input";
/** Remote namespace that carries the client-facing methods. */
export declare const REMOTE_NAMESPACE = "speechrailInput";
/** Default endpoint of the local SpeechRail service. */
export declare const DEFAULT_BASE_URL = "http://127.0.0.1:8201/v1";
/** Credential reference read for every operation; never persisted by this package. */
export declare const DEFAULT_CREDENTIAL_REF = "SPEECHRAIL_API_KEY";
/** One request budget covering connect, upload, inference and download. */
export declare const DEFAULT_REQUEST_TIMEOUT_MS = 150000;
/** Smallest accepted request budget. */
export declare const MIN_REQUEST_TIMEOUT_MS = 1000;
/** Largest accepted request budget. */
export declare const MAX_REQUEST_TIMEOUT_MS = 180000;
/**
 * Largest accepted model id.
 *
 * A model id is a short name the engine recognises (a served name, a file stem), never a path or a
 * token, so this is a sanity bound on a value that reaches a multipart field - not a length any real
 * engine reaches.
 */
export declare const MAX_MODEL_LENGTH = 200;
/** Absolute upload ceiling this package enforces regardless of the advertised service limit. */
export declare const ABSOLUTE_MAX_UPLOAD_BYTES: number;
/** Absolute recording ceiling this package enforces regardless of the advertised service limit. */
export declare const ABSOLUTE_MAX_AUDIO_SECONDS = 120;
/** Largest accepted configuration payload, in bytes of UTF-8 JSON text. */
export declare const CONFIG_PAYLOAD_MAX_BYTES = 8192;
/** Largest accepted transcription payload, in bytes of UTF-8 JSON text. */
export declare const TRANSCRIBE_PAYLOAD_MAX_BYTES = 6291456;
/** Largest accepted transcription response body, in bytes. */
export declare const TRANSCRIPTION_RESPONSE_MAX_BYTES = 262144;
/** Budget for one capability probe, which must never hold the transcription gate. */
export declare const CAPABILITY_TIMEOUT_MS = 5000;
export type * from './types.ts';
/** Closed failure vocabulary shared with the client dictionaries. */
export declare const SPEECHRAIL_FAILURE_CODES: readonly import("./types.ts").SpeechRailFailureCode[];
//# sourceMappingURL=contracts.d.ts.map