/**
 * The composer microphone: one control, drawn by two slots.
 *
 * The button is registered after the model selector and the reporting half inside the model selector's
 * own control group, before it - so this module exports both seats, plus the combined view that draws
 * them in one row for the tests and for any single-seat embedding. The state they share lives in
 * {@link ./control.ts}.
 * @module dsh-voice-input/client/VoiceInput
 */
import type { ReactNode } from 'react';
import { type SpeechRailControl, type SpeechRailSeatProps } from './control.ts';
export type { SpeechRailActions, SpeechRailInjected, SpeechRailSeatProps, VoiceInputProps, } from './control.ts';
/**
 * Both halves in one row.
 * @param props - this Session's seat props.
 * @returns the row the tests and any single-seat embedding see.
 */
export declare function VoiceInput(props: SpeechRailSeatProps): ReactNode;
/**
 * The button's own seat: after the model selector, where the composer expects a compact action.
 *
 * It never reports itself expanded, so the composer keeps its ordinary accessory controls - including
 * the other half of this control - on screen.
 * @param control - the control the plugin owns.
 * @returns the seat component.
 */
export declare function createAnchorSeat(control: SpeechRailControl): (props: SpeechRailSeatProps) => ReactNode;
/**
 * The reporting seat: the model selector's control group, immediately before it.
 * @param control - the control the plugin owns.
 * @returns the seat component.
 */
export declare function createPanelSeat(control: SpeechRailControl): (props: SpeechRailSeatProps) => ReactNode;
//# sourceMappingURL=VoiceInput.d.ts.map