/**
 * Locale-owned copy for the SpeechRail voice input bundle.
 * @module dsh-voice-input/client/locales
 */
/** Dictionary namespace for every SpeechRail control. */
export declare const NS = "voice-input";
/** Chinese dictionary; its keys are the source of truth for both languages. */
export declare const zh: {
    readonly dictate: "语音输入";
    readonly start: "开始录音";
    readonly stop: "结束并转写";
    readonly cancel: "取消录音";
    readonly discard: "丢弃转写结果";
    readonly insert: "插入草稿";
    readonly retryRecording: "重新录音";
    readonly acknowledge: "我已确认服务端未完成";
    readonly acknowledged: "已清除未确认状态";
    readonly recording: "正在录音";
    readonly checking: "正在检查服务";
    readonly requesting: "正在获取麦克风";
    readonly transcribing: "正在转写";
    readonly transcribingShort: "转写中";
    readonly empty: "没有识别到内容，请靠近麦克风重试。";
    readonly tooLarge: "录音超过服务端限制，请缩短时长。";
    readonly conflict: "草稿已改动，结果保留为待插入。";
    readonly failed: "转写失败：{message}";
    readonly unknownOutcome: "无法确认服务端是否已完成（{detail}），请查看服务端记录后再继续。";
    readonly unknownOutcomeLocal: "无法确认本次转写是否已完成（{detail}）。本地日志已记录这次尝试，确认后才能继续。";
    readonly gateBusy: "已有一次转写正在进行。";
    readonly gateUnknown: "存在一次未确认的转写，确认后才能继续。";
    readonly gateReady: "就绪";
    readonly 'capture.permission': "麦克风权限被拒绝，请在浏览器与系统设置中允许。";
    readonly 'capture.unavailable': "当前浏览器无法录音。";
    readonly 'capture.deviceMissing': "找不到可用的麦克风。";
    readonly 'capture.cancelled': "录音已取消。";
    readonly 'capture.interrupted': "录音被设备中断。";
    readonly 'capture.empty': "没有录到音频。";
    readonly 'capture.tooLarge': "录音超过上传上限，请缩短时长。";
    readonly 'failure.endpoint-invalid': "服务地址无效，仅支持本机 127.0.0.1 或 ::1 的 http://…/v1。";
    readonly 'failure.not-configured': "配置的凭据引用解析不出值：请在 DSH 凭据中加入该引用；若该引擎不需要鉴权，把这个引用清空即可。";
    readonly 'failure.bad-request': "服务拒绝了这次上传（HTTP 400/422）。若是首次接入，先确认 model 与该引擎已加载的权重一致。";
    readonly 'failure.audio-invalid': "录音格式不被接受。";
    readonly 'failure.audio-too-long': "录音超过允许的时长上限（默认 120 秒，以能力快照为准），请缩短后再试。";
    readonly 'failure.audio-too-large': "录音超过允许的体积上限（默认 4 MiB，以能力快照为准），请缩短后再试。";
    readonly 'failure.unauthorized': "凭据被拒绝，请检查 API key。";
    readonly 'failure.not-found': "服务端返回 404：通常是端点路径不对，也可能是该模型未加载（vLLM、speaches 都用 404 表示后者）。";
    readonly 'failure.capabilities-absent': "该服务未提供能力接口，将按通用转写端点使用；凭据未经验证。";
    readonly 'failure.redirected': "服务返回了重定向；本插件不跟随重定向，请把地址配置为最终端点。";
    readonly 'failure.unsupported': "本机服务声明不支持文件转写。";
    readonly 'failure.model-not-found': "指定的模型不存在：请核对该引擎已加载的模型 id。";
    readonly 'failure.rate-limited': "服务端限流，请稍后重试。";
    readonly 'failure.server-error': "服务端异常，请查看本地服务日志。";
    readonly 'failure.unreachable': "无法连接本机转写服务。";
    readonly 'failure.timeout': "请求超时。";
    readonly 'failure.cancelled': "已取消。";
    readonly 'failure.busy': "已有一次转写正在进行。";
    readonly 'failure.conflict': "状态与预期不一致，请刷新后重试。";
    readonly 'failure.unknown-outcome': "无法确认服务端状态。";
    readonly 'failure.malformed-response': "服务端响应格式不符合预期。";
    readonly 'failure.journal-unavailable': "本地状态存储不可用，为避免重复上传已停止。";
    readonly 'failure.internal': "插件内部错误。";
    readonly 'settings.description': "通过本机转写服务录音，文本插入当前草稿。";
    readonly 'settings.sectionConnection': "连接";
    readonly 'settings.sectionDictation': "转写";
    readonly 'settings.sectionService': "服务状态";
    readonly 'settings.endpoint': "服务地址";
    readonly 'settings.endpointNote': "仅允许本机回环地址，路径必须为 /v1。";
    readonly 'settings.model': "模型";
    readonly 'settings.modelAuto': "未指定（由服务选择）";
    readonly 'settings.modelNote': "多数引擎要求它，且必须是该引擎已加载权重的名字；留空则由服务选择。";
    readonly 'settings.modelHint': "未设置 model：多数引擎会因此拒绝上传，请填写该引擎已加载的模型名后保存。";
    readonly 'settings.credential': "凭据";
    readonly 'settings.credentialConfigured': "已配置 {ref}";
    readonly 'settings.credentialMissing': "未配置 {ref}";
    readonly 'settings.credentialNone': "无（该引擎不需要鉴权，请求不带 Authorization 头）";
    readonly 'settings.authNone': "未使用凭据";
    readonly 'settings.language': "语言";
    readonly 'settings.languageAuto': "自动";
    readonly 'settings.languageZh': "中文";
    readonly 'settings.languageEn': "英文";
    readonly 'settings.budget': "请求超时（毫秒）";
    readonly 'settings.save': "保存";
    readonly 'settings.saved': "已保存";
    readonly 'settings.conflict': "配置已被其他页面修改，请重新读取后再保存。";
    readonly 'settings.unavailable': "当前环境不支持通过设置页写入。";
    readonly 'settings.limits': "本次生效限制";
    readonly 'settings.limitUpload': "上传上限 {mb} MB";
    readonly languageHintInline: "语言提示 {language}";
    readonly 'settings.limitDuration': "时长上限 {seconds} 秒";
    readonly 'settings.lastCheck': "上次检测：{time}";
    readonly 'settings.never': "尚未检测";
    readonly 'settings.undetermined': "服务未给出";
    readonly 'settings.check': "检测服务";
    readonly 'settings.checking': "检测中";
    readonly 'settings.connected': "连接正常";
    readonly 'settings.unreachable': "连接失败";
    readonly 'settings.authentication': "鉴权：{state}";
    readonly 'settings.authOk': "通过";
    readonly 'settings.authFailed': "失败";
    readonly 'settings.authUnverified': "未验证";
    readonly 'settings.languageNotInEffect': "（未生效：服务未声明支持该语言）";
    readonly 'settings.languageUnverified': "（服务未枚举已支持的语言，按你的选择作为提示发送）";
    readonly 'settings.limitsDefault': "（包内默认值，服务未声明）";
    readonly 'settings.gate': "转写状态";
    readonly 'settings.pendingOperation': "待确认操作：{id}";
    readonly 'settings.transcription': "转写能力";
    readonly 'settings.supported': "可用";
    readonly 'settings.available': "可用";
    readonly 'settings.unsupported': "不可用";
    readonly 'settings.languages': "服务端声明语言：{values}";
    readonly 'shortcut.dictate': "开始或结束语音输入";
    readonly 'shortcut.unavailable': "当前没有可用的输入框";
};
/** Key union shared by both dictionaries. */
export type SpeechRailKey = keyof typeof zh;
/** English dictionary; the type keeps it complete against the Chinese source. */
export declare const en: Record<SpeechRailKey, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** SpeechRail recording and transcription controls. */
        'voice-input': SpeechRailKey;
    }
}
//# sourceMappingURL=locales.d.ts.map