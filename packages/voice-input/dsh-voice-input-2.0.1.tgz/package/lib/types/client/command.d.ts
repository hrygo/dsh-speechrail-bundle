/**
 * The keyboard command that starts and finishes one dictation.
 *
 * The command is a plain value, so its identity, its defaults and both of its resolutions are
 * testable without a Cordis Context; `mount.ts` only hands it to the shortcuts service.
 * @module dsh-voice-input/client/command
 */
import type { ShortcutCommand, ShortcutCommandId } from '@deepseek-ai/dsh-client-shortcuts/client';
import type { DictationTrigger } from './trigger.ts';
/**
 * Copy this module needs, narrowed to the keys it reads and to no dependency on the locale
 * package. A namespace-bound translate accepts at least these keys, so `mount.ts` passes one
 * directly, while a test can pass `(key) => key`.
 */
export type Translate = (key: 'shortcut.dictate' | 'shortcut.unavailable') => string;
/** Stable command identity; the shortcuts registry keys stored preferences by it. */
export declare const DICTATE_COMMAND_ID: ShortcutCommandId;
/** The slice of the shortcuts service this module needs, so it can be driven without a Context. */
export interface ShortcutRegistry {
    /** Contribute one editable command. */
    register: (command: ShortcutCommand) => () => void;
}
/**
 * Describe the dictation command.
 * @param t - copy from this bundle's locale namespace.
 * @param trigger - the channel to the mounted composer control.
 * @returns the command the shortcuts service registers.
 */
export declare function createDictateCommand(t: Translate, trigger: DictationTrigger): ShortcutCommand;
/**
 * Register the command, keeping a rejected registration from taking the bundle down.
 *
 * The registry throws on a duplicate id or an overlapping default binding. Losing the shortcut is
 * a degraded bundle; failing to mount the composer would be a broken one, and the microphone is
 * the feature this bundle exists for.
 * @param shortcuts - the shortcuts service of this composition.
 * @param t - copy from this bundle's locale namespace.
 * @param trigger - the channel to the mounted composer control.
 * @returns idempotent disposer releasing the command.
 */
export declare function registerDictateCommand(shortcuts: ShortcutRegistry, t: Translate, trigger: DictationTrigger): () => void;
//# sourceMappingURL=command.d.ts.map