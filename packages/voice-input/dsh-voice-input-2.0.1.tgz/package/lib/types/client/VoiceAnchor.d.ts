/**
 * The button half of the composer control: one round control, after the model selector.
 *
 * It keeps its place and its size through every phase. This seat can be occupied by a control that
 * expands across the toolbar, and the composer hides its ordinary accessory controls while one is
 * expanded - so this half never reports itself expanded, and everything a press produces is drawn by
 * the other half, in the control group before the model selector.
 * @module dsh-voice-input/client/VoiceAnchor
 */
import type { ReactNode } from 'react';
import type { ControlSnapshot, LocaleText, SpeechRailControl } from './control.ts';
/** Whether a phase is work in progress rather than a recording or a resting control. */
export declare function isWaiting(phase: ControlSnapshot['phase']): boolean;
/** The localized name of a waiting phase. */
export declare function phaseLabel(phase: ControlSnapshot['phase'], t: LocaleText): string;
/**
 * Draw the round control.
 * @param props - the shared control, its snapshot and the locale.
 * @returns the button.
 */
export declare function VoiceAnchorView({ control, snapshot, t }: {
    readonly control: SpeechRailControl;
    readonly snapshot: ControlSnapshot;
    readonly t: LocaleText;
}): ReactNode;
//# sourceMappingURL=VoiceAnchor.d.ts.map