import type { Recording } from './recording.ts';
/**
 * Render a rolling RMS level display for one recording.
 * @param props - recording owner, accessible label, and the strip's shape.
 * @returns the bar strip.
 */
export declare function Waveform({ recording, label, bars, height, color }: {
    readonly recording: Recording | undefined;
    readonly label: string;
    /** How many bars to draw; the newest samples are kept. */
    readonly bars?: number;
    /** Strip height in pixels. */
    readonly height?: number;
    /** Bar colour; `currentColor` follows the control that holds the strip. */
    readonly color?: string;
}): import("react").JSX.Element;
//# sourceMappingURL=Waveform.d.ts.map