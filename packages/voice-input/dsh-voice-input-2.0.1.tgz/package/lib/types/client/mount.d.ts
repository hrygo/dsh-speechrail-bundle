/**
 * Client lifecycle for the SpeechRail Remote contribution, dictionaries and UI slots.
 * @module dsh-voice-input/client/mount
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** Services this client face cannot mount without. */
export declare const inject: string[];
/**
 * Mount the generated Remote namespace together with the browser UI.
 * @param ctx - Client runtime owning the Remote, dictionaries and slots.
 * @param contribution - generated SpeechRail Remote definitions.
 * @returns disposer joining UI and Remote withdrawal.
 */
export declare function mountSpeechRailInput(ctx: Context, contribution: TypertRemoteContribution): Promise<() => Promise<void>>;
//# sourceMappingURL=mount.d.ts.map