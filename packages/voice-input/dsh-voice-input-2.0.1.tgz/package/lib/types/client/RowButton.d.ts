/**
 * The one button shape this bundle draws.
 * @module dsh-voice-input/client/RowButton
 */
import { type CSSProperties, type ReactNode } from 'react';
/**
 * One compact control: a 28px composer button or a settings action, sharing one behaviour.
 *
 * The bundle ships no stylesheet, so every control needs the three things one would otherwise give it:
 * a surface under the pointer, a visible focus ring, and dimming while it refuses interaction. The one
 * exception is a control whose glyph is itself the report of work in progress: dimming that to 55%
 * makes the only thing worth looking at the hardest thing to see, so it stays at full contrast and
 * refuses the press instead. The composer's recording anchor also keeps the draft focused instead of
 * taking the caret out of it.
 * @param props - accessible name, tooltip, interaction flags, busy glyph, geometry, and content.
 * @returns the button.
 */
export declare function RowButton({ label, title, disabled, keepFocus, busy, onClick, style, children }: {
    readonly label: string;
    readonly title?: string;
    readonly disabled?: boolean;
    readonly keepFocus?: boolean;
    /** The glyph reports work in progress, so it keeps full contrast while the press is refused. */
    readonly busy?: boolean;
    readonly onClick: () => void;
    readonly style: CSSProperties;
    readonly children: ReactNode;
}): import("react").JSX.Element;
//# sourceMappingURL=RowButton.d.ts.map