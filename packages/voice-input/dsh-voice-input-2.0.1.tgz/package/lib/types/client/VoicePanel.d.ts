/**
 * The reporting half of the composer control: everything a press produces, before the model selector.
 *
 * The button lives in another seat, after the model selector, so a live take never moves it. What is
 * left here is the information and the two recovery actions: how long the take has run, which phase it
 * is in, the cancel control, the message, and the transcript a refused draft still owes the user.
 * @module dsh-voice-input/client/VoicePanel
 */
import type { ReactNode } from 'react';
import type { ControlSnapshot, LocaleText, SpeechRailControl } from './control.ts';
/**
 * Draw the reporting half.
 * @param props - the shared control, its snapshot and the locale.
 * @returns the panel's elements.
 */
export declare function VoicePanelView({ control, snapshot, t }: {
    readonly control: SpeechRailControl;
    readonly snapshot: ControlSnapshot;
    readonly t: LocaleText;
}): ReactNode;
//# sourceMappingURL=VoicePanel.d.ts.map