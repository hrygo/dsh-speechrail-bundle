/**
 * The composer microphone as one state machine, drawn by two slots.
 *
 * The button sits after the model selector, and what a press produces - timer, cancel, message,
 * insert - stays in the control group before it. Two components in two slots cannot own one take, so
 * the state lives here: one microphone, one take at a time, two views over the same snapshot.
 *
 * Everything in the snapshot is raw state. Phase names, colours and failure text are derived by the
 * views from their own localized `t`, so binding a face never invalidates what the other view reads.
 * @module dsh-voice-input/client/control
 */
import type { PropsLocale, PropsRuntime, InjectFace } from '@deepseek-ai/dsh-client-ui-slots';
import type { InputActions } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { SpeechRailAcknowledgeRequest, SpeechRailAcknowledgeResult, SpeechRailCheckResult, SpeechRailConfigureRequest, SpeechRailConfigureResult, SpeechRailInputStatus, SpeechRailTranscribeRequest, SpeechRailTranscriptionResult } from '../contracts.ts';
import { NS } from './locales.ts';
import { type Recording } from './recording.ts';
import type { DictationTrigger } from './trigger.ts';
/** Host calls injected without exposing a Cordis Context to React. */
export interface SpeechRailActions {
    /** Read status, limits and the current gate. */
    status: () => Promise<SpeechRailInputStatus>;
    /** Probe the service and refresh cached capabilities. */
    check: () => Promise<SpeechRailCheckResult>;
    /** Persist language and request budget. */
    configure: (request: SpeechRailConfigureRequest) => Promise<SpeechRailConfigureResult>;
    /** Clear an unproven remote outcome. */
    acknowledge: (request: SpeechRailAcknowledgeRequest) => Promise<SpeechRailAcknowledgeResult>;
    /** Upload one recording exactly once. */
    transcribe: (request: SpeechRailTranscribeRequest, signal: AbortSignal) => Promise<SpeechRailTranscriptionResult>;
    /** Own one microphone acquisition for the plugin lifecycle. */
    createRecording: () => Recording;
    /**
     * Channel opened by the keyboard command this bundle registers.
     *
     * Separate from the seat's own props on purpose: whether a control would accept a press is told to
     * the seat, and this channel must stay open across every composer state.
     */
    dictation: DictationTrigger;
}
/** Entry-injected Host operations. */
export type SpeechRailInjected = SpeechRailActions;
/** Locale function as a seat receives it: typed by this bundle's own dictionary. */
export type LocaleText = PropsLocale<typeof NS>['t'];
/** Locale function, widened: only this bundle's own message keys pass through the control. */
export type Translate = (key: string, values?: Record<string, unknown>) => string;
/** What both seats provide: this Session's draft actions, its dictionary and the Host face. */
export type SpeechRailSeatProps = Pick<PropsRuntime<'conversation.input.right'>, 'inputActions'> & PropsLocale<typeof NS> & InjectFace<SpeechRailInjected>;
/** The face a single-seat render needs, as the tests and the combined view pass it. */
export type VoiceInputProps = SpeechRailSeatProps;
/** Which part of the control's life the microphone is in. */
export type Phase = 'idle' | 'checking' | 'requesting' | 'recording' | 'transcribing' | 'feedback';
/**
 * How a message reads.
 *
 * One grey for a refusal and for "working on it" made the row's worst states look like its best ones,
 * so the kind travels with the text and picks the colour.
 */
export type MessageKind = 'info' | 'warn' | 'error' | 'success';
/** Everything either view draws, as raw state. */
export interface ControlSnapshot {
    readonly phase: Phase;
    readonly message: string;
    readonly messageKind: MessageKind;
    /** A transcript the draft refused, kept for a later insertion. */
    readonly pending: string;
    /** Whole seconds the live take has run. */
    readonly elapsed: number;
    readonly gate: SpeechRailInputStatus['gate'] | undefined;
    readonly pendingOperationId: SpeechRailInputStatus['pendingOperationId'] | undefined;
    readonly unprovenFailure: SpeechRailInputStatus['unprovenFailure'] | undefined;
    /** The language hint in force for the take being transcribed. */
    readonly languageHint: string;
    readonly ackBusy: boolean;
    /** The live acquisition, so the waveform can sample it; only set while recording. */
    readonly capture: Recording | undefined;
}
/**
 * One microphone, shared by the two slots it is drawn in.
 *
 * Bound by whichever half renders, and disposed with the plugin: the browser listeners that cancel a
 * take (Escape, window blur, a hidden page) belong to the control, not to a component that a composer
 * change could unmount mid-take.
 */
export declare class SpeechRailControl {
    private readonly listeners;
    private snapshot;
    private faces;
    private dictationOff;
    private started;
    private active;
    private generation;
    private view;
    private statusSeq;
    private ticker;
    private translate;
    private readonly onBlur;
    private readonly onVisibility;
    private readonly onKeydown;
    constructor();
    /** The snapshot React reads; the same object until something actually changes. */
    readonly getSnapshot: () => ControlSnapshot;
    /** Subscribe to state changes. */
    readonly subscribe: (listener: () => void) => (() => void);
    /**
     * Adopt the faces of the half that just rendered.
     *
     * Both halves carry the same injected Host calls and the same Session draft actions, so the last one
     * to render wins - the microphone is one resource, and the composer on screen is the one it serves.
     * The first bind also reads the status once, which is what a mount used to do.
     * @param injected - the Host face and the dictation channel.
     * @param inputActions - this Session's draft actions.
     * @param translate - the locale both halves share.
     */
    bind(injected: SpeechRailInjected, inputActions: InputActions, translate: Translate): void;
    /** Stop owning the microphone and every listener. */
    dispose(): void;
    /** The keyboard's press: start from idle, finish a live take, and change nothing else. */
    press(): void;
    /** Open the microphone, after checking everything that would make the upload pointless. */
    start(): Promise<void>;
    /** Stop the take, upload it once and insert what comes back. */
    finish(): Promise<void>;
    /** Discard the live take without sending anything. */
    cancel(): void;
    /** Insert the transcript the draft refused earlier. */
    insertPending(): boolean;
    /** Clear an unproven outcome the host still holds. */
    acknowledgeUnknown(): Promise<void>;
    private take;
    /**
     * Localized message text.
     *
     * An arrow property, not a method: `failureText` and the message helpers take this function and call
     * it unbound, which a prototype method cannot survive.
     */
    private readonly t;
    private captureText;
    private show;
    private feedback;
    private refresh;
    private startTicker;
    private stopTicker;
    private setState;
}
/**
 * A control owned by one component's lifetime.
 *
 * The two slots share the controller the plugin creates; this is for the case where both halves render
 * inside one tree (the combined view, and the tests), so state starts and ends with that tree.
 * @returns the control.
 */
export declare function useOwnControl(): SpeechRailControl;
/**
 * Read the control, hand it this half's faces, and return what to draw.
 *
 * Binding happens after every render: the faces are plain object identities, compared inside, so a
 * phase change never rebuilds the dictation subscription, and a new Session facade is adopted without
 * resetting a take that is still running. A press can only happen once mounted, so the faces are always
 * in place by then.
 * @param control - the shared control.
 * @param props - this half's seat props.
 * @returns the raw state the view draws.
 */
export declare function useControl(control: SpeechRailControl, props: SpeechRailSeatProps): ControlSnapshot;
//# sourceMappingURL=control.d.ts.map