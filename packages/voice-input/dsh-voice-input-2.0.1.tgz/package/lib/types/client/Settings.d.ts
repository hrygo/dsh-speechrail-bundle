/**
 * Settings page for the SpeechRail voice input bundle.
 * @module dsh-voice-input/client/Settings
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
import type { SpeechRailInjected } from './VoiceInput.tsx';
/** Full props of the bundle configuration page. */
export type SpeechRailSettingsProps = PropsRuntime<'plugins.bundle.config'> & PropsLocale<typeof NS> & InjectFace<SpeechRailInjected>;
/** Render status, editable language and budget, and the probe result. */
export declare function SpeechRailSettings({ t, status, check, configure, acknowledge }: SpeechRailSettingsProps): import("react").JSX.Element;
//# sourceMappingURL=Settings.d.ts.map