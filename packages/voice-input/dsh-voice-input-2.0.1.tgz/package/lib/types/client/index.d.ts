/**
 * Browser entry for the SpeechRail Remote contribution and composer control.
 * @module dsh-voice-input/client
 */
import type { Context } from '@deepseek-ai/cordis';
export { inject } from './mount.ts';
/**
 * Activate the SpeechRail microphone contribution.
 * @param ctx - Client runtime.
 * @returns complete UI and Remote disposer.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map