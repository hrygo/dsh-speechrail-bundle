/**
 * Browser-owned microphone capture and native Web Audio resampling.
 *
 * The capture lifecycle follows the behaviour of the frozen official baseline
 * (`upstream/.../client-ui-voice-input/src/client/audio.ts`, MIT): a permission
 * grant that settles after cancellation releases its tracks immediately, device
 * interruption tears the recording down before the caller is notified, and the
 * recorded blob is decoded and resampled to 16 kHz mono by an OfflineAudioContext.
 * @module dsh-voice-input/client/recording
 */
/** Capture failure whose localized text is chosen by the caller. */
export declare class RecordingError extends Error {
    readonly kind: 'unavailable' | 'permission' | 'empty' | 'cancelled' | 'interrupted' | 'deviceMissing' | 'tooLarge';
    constructor(kind: 'unavailable' | 'permission' | 'empty' | 'cancelled' | 'interrupted' | 'deviceMissing' | 'tooLarge');
}
/**
 * Encode a recording for the JSON Remote carrier.
 * @param bytes - complete WAV bytes.
 * @returns base64 with no data-URL prefix.
 */
export declare function audioBase64(bytes: Uint8Array): string;
/** One microphone acquisition, including a permission prompt that may settle after cancellation. */
export declare class Recording {
    private readonly onDispose;
    private readonly deviceId;
    private stream;
    private recorder;
    private context;
    private analyser;
    private readonly samples;
    private chunks;
    private readonly lifetime;
    private disposal;
    constructor(onDispose: () => void, deviceId?: string);
    /**
     * Acquire the selected microphone without recording or playing audio.
     * @param onError - receives device interruptions before resource release completes.
     * @returns after the level analyser starts.
     */
    preview(onError?: (error: RecordingError) => void): Promise<void>;
    /**
     * Acquire the selected microphone and start recording.
     * @param onError - receives failures that happen while capture is live.
     * @returns after capture starts.
     */
    start(onError?: (error: RecordingError) => void): Promise<void>;
    /**
     * Read the live microphone signal.
     * @returns the measured RMS level, or zero outside capture.
     */
    amplitude(): number;
    /**
     * Finish capture and resample the recording to canonical 16 kHz mono WAV.
     * @param maxDurationSeconds - truncate timer overshoot to the admitted limit.
     * @param maxBytes - admitted upload ceiling, checked before the caller uploads.
     * @returns one WAV recording after the final MediaRecorder chunk arrives.
     */
    stop(maxDurationSeconds: number, maxBytes: number): Promise<Uint8Array>;
    /**
     * Release this recording and invalidate pending permission grants.
     * @returns the shared release promise, including any AudioContext close failure.
     */
    dispose(): Promise<void>;
    /** Tear resources down once and report interruption. */
    private interrupted;
    /** Release tracks, recorder and audio context exactly once. */
    private release;
}
//# sourceMappingURL=recording.d.ts.map