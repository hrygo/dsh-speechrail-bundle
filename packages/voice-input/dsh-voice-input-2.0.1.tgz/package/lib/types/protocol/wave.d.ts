/**
 * Strict canonical-WAV validation shared by the Host and the browser client.
 *
 * The same rules run before upload and before inference, so an encoder regression
 * fails locally instead of consuming a remote model slot.
 * @module dsh-voice-input/protocol/wave
 */
/** Why a recording was refused. */
export type WaveRefusal = 'too-short' | 'not-riff' | 'not-pcm16-mono-16k' | 'length-mismatch' | 'too-long';
/** Accepted canonical recording. */
export interface WaveAccepted {
    /** Whether the bytes are a canonical recording. */
    readonly ok: true;
    /** Recording duration in seconds derived from the data chunk. */
    readonly seconds: number;
    /** Total byte length. */
    readonly byteLength: number;
}
/** Refused recording. */
export interface WaveRejected {
    /** Whether the bytes are a canonical recording. */
    readonly ok: false;
    /** Stable machine-readable refusal reason. */
    readonly reason: WaveRefusal;
}
/** Result of validating one recording. */
export type WaveResult = WaveAccepted | WaveRejected;
/**
 * Validate that a recording is exactly the canonical 16 kHz mono PCM16 WAV this
 * service accepts, rejecting any header or length inconsistency.
 * @param audio - candidate bytes.
 * @param maxDurationSeconds - maximum admitted duration.
 * @returns the duration and length, or the reason the bytes were refused.
 */
export declare function validateWave(audio: Uint8Array, maxDurationSeconds: number): WaveResult;
/**
 * Encode mono floating-point samples as the canonical PCM16 WAV this service accepts.
 * @param samples - 16 kHz mono samples in the range -1..1.
 * @returns complete little-endian WAV bytes.
 */
export declare function encodeWave(samples: Float32Array): Uint8Array;
/**
 * Read the recording duration of already-validated canonical bytes.
 * @param audio - canonical WAV bytes.
 * @returns duration in seconds.
 */
export declare function waveSeconds(audio: Uint8Array): number;
//# sourceMappingURL=wave.d.ts.map