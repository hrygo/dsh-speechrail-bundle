/**
 * Independent SpeechRail voice input bundle: Host entry.
 *
 * The bundle deliberately owns one service and one Remote surface, and reuses no
 * official voice package at runtime. Browser capture lives in the Client face.
 * @module dsh-voice-input
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SpeechRailInputConfig } from './host/config.ts';
export { Config } from './host/config.ts';
export { default as SpeechRailInput } from './host/service.ts';
export { default as SpeechRailInputController } from './host/controller.ts';
export type * from './contracts.ts';
/** Loader entry id this bundle's patch inserts. */
export declare const name = "voice-input";
/**
 * Hard requirements of this entry. Settings, storage and the Remote registry stay
 * optional so a composition without them loads and reports why it cannot record.
 */
export declare const inject: string[];
/**
 * Register the transcription service and its authenticated Remote surface.
 *
 * The journal is read before the Remote is mounted, so a client can never observe a
 * gate that has not yet accounted for an earlier unproven upload.
 * @param ctx - Host context owning the entry.
 * @param config - validated entry configuration.
 * @returns after the service is reachable.
 */
export declare function apply(ctx: Context, config: SpeechRailInputConfig): Promise<void>;
//# sourceMappingURL=index.d.ts.map