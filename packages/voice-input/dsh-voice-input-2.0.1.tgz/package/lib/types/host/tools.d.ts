/**
 * Thin agent entry point.
 *
 * One read-only tool that reports whether local voice input is usable, so an agent
 * can explain a failure ("the service is not running", "the credential is missing",
 * "an earlier recording still needs acknowledgement") without the user opening the
 * settings page. It records nothing, uploads nothing and never exposes the
 * credential: only the reference and a boolean cross the boundary.
 *
 * The definition is written structurally instead of through `@deepseek-ai/dsh-tools`
 * because importing that package's declarations pulls `@deepseek-ai/dsh-llm` into the
 * Typert-analyzed program, where an unrelated lookup declaration fails analysis. The
 * shapes below are exactly what that package compiles to; `tools/check-tool-schema.mjs`
 * asserts both the compiled-JSON parity and the registry's own schema check, because
 * the compiler cannot.
 *
 * Registering this way validates `output.schema` and every result against it, but it
 * does not validate arguments: `execute` therefore treats only an explicit
 * `probe: true` as a probe and tolerates every other value.
 * @module dsh-voice-input/host/tools
 */
import type { SpeechRailAuthentication, SpeechRailCheckResult, SpeechRailInputStatus, SpeechRailTranscriptionSupport } from '../types.ts';
/** Registered tool name. */
export declare const STATUS_TOOL_NAME = "voice_input_status";
/** One model-facing text block. */
export interface ToolTextBlock {
    /** Content block discriminator. */
    readonly type: 'text';
    /** Bounded text handed to the model. */
    readonly text: string;
}
/** Implicit open object root the registry sends to the model. */
export interface ToolParameterSchema {
    /** Node type of the parameter root. */
    readonly type: 'object';
    /** Per-property schemas. */
    readonly properties: Readonly<Record<string, unknown>>;
    /** Names that must be present; omitted when every property is optional. */
    readonly required?: readonly string[];
    /** Whether undeclared properties are rejected. */
    readonly additionalProperties?: boolean;
}
/** Tool definition shape accepted by the Harness tools registry. */
export interface HarnessToolDefinition {
    /** Unique tool name. */
    readonly name: string;
    /** Model-facing description. */
    readonly description: string;
    /** Parameter schema. */
    readonly parameters: ToolParameterSchema;
    /** Canonical output schema plus its projection. */
    readonly output: {
        /** Raw JSON Schema enforced against every successful value. */
        readonly schema: Readonly<Record<string, unknown>>;
        /** Projection from validated arguments and value to model content. */
        render(args: unknown, value: unknown): readonly ToolTextBlock[];
    };
    /**
     * Run one accepted call.
     * @param args - validated model arguments.
     * @returns the canonical value declared by `output.schema`.
     */
    execute(args: {
        readonly probe?: boolean;
    }): Promise<StatusToolValue>;
}
/** The only part of the Harness tools service this bundle uses. */
export interface ToolRegistry {
    /**
     * Add one tool for the life of the caller's scope.
     * @param definition - registry-ready definition.
     * @returns the disposer that withdraws the tool.
     */
    register(definition: HarnessToolDefinition): () => void;
}
/** Host surface the tool reads; narrowed so a test can stub it. */
export interface StatusToolSource {
    /** Read the current state without touching the network. */
    status(): Promise<SpeechRailInputStatus>;
    /** Probe the local service once and report reachability and limits. */
    check(): Promise<SpeechRailCheckResult>;
}
/** Canonical value this tool returns. */
export interface StatusToolValue {
    /** Whether the configured credential reference resolves to a non-empty value. */
    readonly credentialConfigured: boolean;
    /**
     * Whether this endpoint is configured to present a credential at all.
     *
     * False only when the reference was deliberately cleared, which is how a local engine that
     * authenticates nobody is configured. Only this boolean crosses the boundary: the reference name
     * stays on the Host. See ADR-0003.
     */
    readonly credentialRequired: boolean;
    /** Effective loopback base URL, or an empty string when it was refused. */
    readonly endpoint: string;
    /** Why the configured endpoint is unusable, or an empty string. */
    readonly endpointProblem: string;
    /** Configured model id, or an empty string when the service chooses. */
    readonly model: string;
    /** Configured language mode. */
    readonly language: string;
    /** Language hint the next upload will actually carry, or an empty string when none will. */
    readonly languageHint: string;
    /**
     * What is known about the transcription operation: `unsupported` means every upload is refused.
     *
     * Deliberately not named like `SpeechRailCapabilitiesView.transcriptionSupported`, which is the
     * service's own boolean claim: the two travel on the same boundary and same-named fields of
     * different types invite exactly the confusion this type exists to remove.
     */
    readonly transcriptionSupport: SpeechRailTranscriptionSupport;
    /** Language modes the snapshot in force admits for this endpoint. */
    readonly languageOptions: readonly string[];
    /** Whether a recording may start, or the state blocking it. */
    readonly gate: string;
    /** Operation id awaiting acknowledgement, or an empty string. */
    readonly pendingOperationId: string;
    /** Largest upload the next recording may produce. */
    readonly maxUploadBytes: number;
    /** Longest recording the next upload may contain. */
    readonly maxAudioSeconds: number;
    /** Whether the local service was asked during this call. */
    readonly probed: boolean;
    /** Whether the local service answered; false when it was not asked. */
    readonly reachable: boolean;
    /** What the probe proved about the credential; `unverified` when it judged nothing. */
    readonly authenticated: SpeechRailAuthentication;
    /** Failure code of the probe in this call, or an empty string. */
    readonly failureCode: string;
    /** Failure code of the upload whose outcome is unproven, or an empty string. */
    readonly unprovenFailureCode: string;
    /** HTTP status that upload received, or 0 when nothing answered. */
    readonly unprovenFailureHttpStatus: number;
}
/**
 * Build the status tool over one Host service.
 * @param source - Host service to read.
 * @returns a registry-ready definition.
 */
export declare function createStatusTool(source: StatusToolSource): HarnessToolDefinition;
/**
 * One-line human summary of a canonical value.
 * @param value - validated tool value.
 * @returns the model-facing text.
 */
export declare function describeStatus(value: StatusToolValue): string;
//# sourceMappingURL=tools.d.ts.map