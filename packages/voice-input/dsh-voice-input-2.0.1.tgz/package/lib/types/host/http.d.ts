/**
 * Bounded, direct HTTP access to the local SpeechRail service.
 *
 * Every request is issued through `node:http` with an explicit loopback host and
 * port. Redirects are never followed, responses are byte-capped, and one deadline
 * covers the whole exchange. `agent: false` is what keeps a host that enabled Node's
 * opt-in environment proxy (`NODE_USE_ENV_PROXY` / `--use-env-proxy`, Node >= 24.5) from
 * routing this request: measured on Node 26.11.1, a request through the default agent
 * reached the proxy while this shape connected to its target directly.
 * @module dsh-voice-input/host/http
 */
import { type SpeechRailCapabilitiesView, type SpeechRailFailure } from '../contracts.ts';
import type { SpeechRailAuthentication, SpeechRailLimits } from '../types.ts';
/** One low-level response. */
export interface HttpSuccess {
    /** Whether a response arrived. */
    readonly ok: true;
    /** Response status code. */
    readonly status: number;
    /** Response body, already byte-capped. */
    readonly body: Buffer;
    /**
     * Whether the response stated its own length, so its body is provably complete.
     *
     * Without this the body ends when the socket does, and a reply cut mid-transcript cannot be told
     * from a complete one. See {@link framingProof} for why only a stated length qualifies.
     */
    readonly framed: boolean;
}
/** One low-level failure. */
export interface HttpFailure {
    /** Whether a response arrived. */
    readonly ok: false;
    /** Sanitized failure. */
    readonly failure: SpeechRailFailure;
}
/** Result of one low-level exchange. */
export type HttpResult = HttpSuccess | HttpFailure;
/** Options of one low-level exchange. */
export interface HttpRequestOptions {
    /** Absolute URL, already validated as loopback. */
    readonly url: string;
    /** HTTP method. */
    readonly method: 'GET' | 'POST';
    /** Request headers. */
    readonly headers: Readonly<Record<string, string>>;
    /** Request body, for POST. */
    readonly body?: Buffer | undefined;
    /** One deadline covering connect, upload, processing and download. */
    readonly timeoutMs: number;
    /** Response byte cap. */
    readonly maxResponseBytes: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal | undefined;
}
/**
 * Issue one exchange with an explicit direct socket.
 * @param options - request description.
 * @returns the capped response, or a sanitized failure plus whether bytes were written.
 */
/**
 * Strip the brackets `new URL` keeps around an IPv6 literal.
 *
 * Node treats `'[::1]'` as a name to resolve rather than as an address, so passing it
 * through would send a loopback-only request to whatever DNS answers — or fail.
 * @param hostname - `URL.hostname`, possibly bracketed.
 * @returns the bare address, suitable for `http.request`.
 */
export declare function unbracketHostname(hostname: string): string;
export declare function performRequest(options: HttpRequestOptions): Promise<HttpResult>;
/** Encode one multipart/form-data body with a random boundary. */
export declare function encodeMultipart(fields: Readonly<Record<string, string>>, file: {
    readonly name: string;
    readonly filename: string;
    readonly contentType: string;
    readonly data: Uint8Array;
}, boundary: string): Buffer;
/** Options for one transcription upload. */
export interface TranscribeOptions {
    /** Normalized loopback base URL. */
    readonly baseUrl: string;
    /** Optional explicit model id; an empty string omits the field. */
    readonly model: string;
    /** Language hint, or null to let the service decide. */
    readonly language: string | null;
    /** Resolved bearer credential, or null when the endpoint needs none. */
    readonly credential: string | null;
    /** Canonical WAV bytes. */
    readonly audio: Uint8Array;
    /** One request budget. */
    readonly timeoutMs: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal | undefined;
}
/** Accepted transcription. */
export interface TranscribeAccepted {
    /** Whether a usable transcript arrived. */
    readonly ok: true;
    /** Recognized text. */
    readonly text: string;
    /** Wall-clock duration of the whole exchange. */
    readonly requestSeconds: number;
}
/** Refused transcription. */
export interface TranscribeRefused {
    /** Whether a usable transcript arrived. */
    readonly ok: false;
    /** Sanitized failure. */
    readonly failure: SpeechRailFailure;
}
/** Result of one transcription upload. */
export type TranscribeOutcome = TranscribeAccepted | TranscribeRefused;
/**
 * Upload one canonical recording and read the JSON transcript.
 * @param options - upload description.
 * @returns the text and wall-clock duration, or a sanitized failure.
 */
export declare function transcribe(options: TranscribeOptions): Promise<TranscribeOutcome>;
/** Options for one capability probe. */
export interface ProbeOptions {
    /** Normalized loopback base URL. */
    readonly baseUrl: string;
    /** Resolved bearer credential, or null when the endpoint needs none. */
    readonly credential: string | null;
    /** Probe budget; defaults to the capability timeout. */
    readonly timeoutMs?: number | undefined;
    /** Caller cancellation. */
    readonly signal?: AbortSignal | undefined;
    /** Limits in force before this probe; a limit the snapshot omits keeps its value. */
    readonly previousLimits?: SpeechRailLimits | null | undefined;
}
/** Successful probe. */
export interface ProbeAccepted {
    /** Whether the probe produced a usable snapshot. */
    readonly ok: true;
    /** Projected capability facts, or null when the body was not a snapshot. */
    readonly capabilities: SpeechRailCapabilitiesView | null;
}
/** Failed probe that still reached the service. */
export interface ProbeRefused {
    /** Whether the probe produced a usable snapshot. */
    readonly ok: false;
    /** Whether any HTTP response arrived. */
    readonly reachable: boolean;
    /** What that response proved about the credential. */
    readonly authenticated: SpeechRailAuthentication;
    /** Sanitized failure, or null when the response simply was not a snapshot. */
    readonly failure: SpeechRailFailure | null;
}
/** Result of one capability probe. */
export type ProbeOutcome = ProbeAccepted | ProbeRefused;
/**
 * Read the effective capability snapshot.
 * @param options - probe description.
 * @returns projected facts, or a classified refusal that never carries the body.
 */
export declare function probeCapabilities(options: ProbeOptions): Promise<ProbeOutcome>;
//# sourceMappingURL=http.d.ts.map