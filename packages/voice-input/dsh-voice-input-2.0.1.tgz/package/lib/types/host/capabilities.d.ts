/**
 * Defensive projection of the untrusted SpeechRail capability snapshot.
 *
 * Nothing here trusts a field: an absent, mistyped or unexpected value degrades to
 * "unknown", and a snapshot that does not enumerate languages never decides one for the service: the
 * selector offers every known mode and the choice travels as an unverified hint.
 * @module dsh-voice-input/host/capabilities
 */
import { type SpeechRailCapabilitiesView, type SpeechRailLanguageMode, type SpeechRailLimits } from '../contracts.ts';
/**
 * Limits enforced before any snapshot has been read: the package's own ceilings, so
 * nothing a service can legitimately advertise is refused on a guess. They are the
 * widest values this package accepts, not conservative ones.
 */
export declare const DEFAULT_LIMITS: SpeechRailLimits;
/**
 * Clamp advertised limits to this package's absolute ceilings.
 *
 * A limit the snapshot does not state keeps the value already in force. Falling back
 * to the absolute ceiling here would widen what this host accepts whenever a service
 * recognises as a transcription endpoint without stating its input limits.
 * @param advertised - limits read from a snapshot, each possibly null when unstated.
 * @param previous - limits in force before this snapshot, if any.
 * @returns effective limits that never exceed the package ceilings.
 */
export declare function clampLimits(advertised: {
    readonly maxUploadBytes: number | null;
    readonly maxAudioSeconds: number | null;
}, previous?: SpeechRailLimits | null): SpeechRailLimits;
/**
 * Project the `transcription` operation of an `effective_capabilities_v1` snapshot.
 * @param snapshot - decoded response body, untrusted.
 * @returns the projected facts, or null when the body is not a usable snapshot.
 */
export declare function projectCapabilities(snapshot: unknown, previous?: SpeechRailLimits | null): SpeechRailCapabilitiesView | null;
/**
 * Language modes the selector may offer for one snapshot.
 *
 * Three cases, and the distinction that matters is whether the endpoint can transcribe at all:
 * - it cannot (`transcriptionSupported === false`): only `auto`. The upload is refused before the
 *   audio leaves the host, so offering a hint would promise a choice that cannot be exercised;
 * - it can, and the snapshot enumerated languages: only the modes whose exact value it listed;
 * - it can, but nothing enumerated the languages (no snapshot at all, or a snapshot whose language
 *   domain is `unknown`): every known mode is offered and the chosen one travels as an unverified
 *   hint. SpeechRail itself answers this way -- its transcription endpoint documents `language` as
 *   a hint ("BCP-47-style or provider-compatible", example `zh`) while its capability snapshot
 *   states `languages.status: unknown` -- so refusing the choice here would lose a real capability.
 * @param view - projected capability facts, or null when none is in force.
 * @returns `auto` always, plus the modes worth offering.
 */
export declare function languageOptionsFor(view: SpeechRailCapabilitiesView | null): readonly SpeechRailLanguageMode[];
/**
 * Decide whether a configured language mode may be sent.
 * @param mode - configured mode.
 * @param view - projected capability facts, or null.
 * @returns true when the mode is automatic or the snapshot admits it.
 */
export declare function languageIsAdmitted(mode: SpeechRailLanguageMode, view: SpeechRailCapabilitiesView | null): boolean;
//# sourceMappingURL=capabilities.d.ts.map