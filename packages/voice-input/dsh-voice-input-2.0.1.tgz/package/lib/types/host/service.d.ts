/**
 * Host service binding the transcription engine to DSH credentials, storage and settings.
 * @module dsh-voice-input/host/service
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import { type SpeechRailAcknowledgeResult, type SpeechRailCheckResult, type SpeechRailConfigureResult, type SpeechRailInputStatus, type SpeechRailTranscriptionResult } from '../contracts.ts';
import { type SpeechRailInputConfig } from './config.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Independent SpeechRail voice input service. */
        speechrailInput: SpeechRailInput;
    }
}
/** Transcription service: one in-flight operation, one durable pending record. */
export default class SpeechRailInput extends Service {
    private readonly config;
    /** Entry configuration schema rendered by the settings page. */
    static Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
        baseUrl: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        model: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        credentialRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        language: import("@deepseek-ai/schemastery").default<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
        requestTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        baseUrl: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        model: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        credentialRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        language: import("@deepseek-ai/schemastery").default<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
        requestTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
    }>>, "plain">;
    private readonly core;
    private readonly entryId;
    private readonly opened;
    constructor(ctx: Context, config: SpeechRailInputConfig);
    /**
     * Read the durable journal so an unproven earlier upload survives a reload.
     * @returns after the gate reflects what the medium already holds.
     */
    restore(): Promise<void>;
    /** Release the storage unit this service opened. */
    dispose(): void;
    /** @returns everything the settings page and composer control render. */
    status(): Promise<SpeechRailInputStatus>;
    /** @returns what one connectivity and capability probe observed. */
    check(): Promise<SpeechRailCheckResult>;
    /**
     * Persist language and request budget after a revision check.
     * @param payload - JSON carrier text.
     * @returns the new revision or a localized-code failure.
     */
    configure(payload: string): Promise<SpeechRailConfigureResult>;
    /**
     * Upload one recording without ever replaying or queuing it.
     * @param payload - JSON carrier text holding the operation id and base64 audio.
     * @param signal - caller cancellation.
     * @returns the transcript, or a sanitized failure.
     */
    transcribe(payload: string, signal?: AbortSignal | undefined): Promise<SpeechRailTranscriptionResult>;
    /**
     * Clear an unproven outcome the user explicitly acknowledged.
     * @param payload - JSON carrier text holding the operation id.
     * @returns the remaining pending operation, or a refusal.
     */
    acknowledgeUnknown(payload: string): Promise<SpeechRailAcknowledgeResult>;
    /** Read the effective configuration, normalizing the endpoint on every call. */
    private resolveConfig;
    /** Resolve the credential reference, treating a refusal as absent. */
    private resolveCredential;
    /** Current revision of this entry's settings namespace. */
    private settingsRevision;
    /** Persist the editable subset of this entry. */
    private writeSettings;
    /**
     * Build the durable journal over the JSON storage backend.
     *
     * Without a usable medium every question fails closed, so this package never
     * uploads audio it could not account for after a reload.
     */
    private createJournal;
}
//# sourceMappingURL=service.d.ts.map