/**
 * Loopback-only endpoint normalization for the local SpeechRail service.
 * @module dsh-voice-input/host/endpoint
 */
/** Why a configured endpoint was refused. */
export type EndpointRefusal = 'not-a-url' | 'insecure-scheme' | 'not-loopback' | 'has-credentials' | 'has-query' | 'has-fragment' | 'wrong-path';
/** Accepted endpoint: the exact base URL every request is built from. */
export interface EndpointAccepted {
    /** Whether the value was accepted. */
    readonly ok: true;
    /** Normalized base URL ending in `/v1`, with no trailing slash. */
    readonly baseUrl: string;
    /** Request origin this endpoint resolves to, for diagnostics only. */
    readonly origin: string;
}
/** Refused endpoint. */
export interface EndpointRejected {
    /** Whether the value was accepted. */
    readonly ok: false;
    /** Stable machine-readable refusal reason. */
    readonly reason: EndpointRefusal;
}
/** Result of normalizing one configured endpoint. */
export type EndpointResult = EndpointAccepted | EndpointRejected;
/**
 * Normalize a configured SpeechRail endpoint, refusing anything that is not a plain
 * HTTP loopback address with the exact `/v1` base path.
 *
 * Loopback-only is a security property, not a preference: the credential is a local
 * bearer secret and must never travel to a remote or proxied destination.
 * @param input - raw configured endpoint.
 * @returns the normalized base URL, or the reason it was refused.
 */
export declare function normalizeEndpoint(input: string): EndpointResult;
/**
 * Human-readable refusal text. It names only the refusal kind, never the configured
 * value, and this is what the status projection sends to clients as
 * `endpointProblem`.
 */
export declare function describeRefusal(reason: EndpointRefusal): string;
//# sourceMappingURL=endpoint.d.ts.map