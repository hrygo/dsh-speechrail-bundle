/**
 * Declarative configuration of this bundle's Loader entry.
 * @module dsh-voice-input/host/config
 */
import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type SpeechRailLanguageMode } from '../contracts.ts';
/**
 * Entry schema rendered by the settings page.
 *
 * `language`, `model` and `requestTimeoutMs` are volatile so a settings write applies to
 * the next operation without reloading the plugin. A volatile field parses to a
 * `{ get() }` handle rather than a plain value, so it must never be read directly:
 * {@link readConfig} is the only sanctioned reader.
 *
 * The endpoint and the credential reference stay static because changing either re-points
 * where a local secret is sent; the model id does not go anywhere near that decision - it
 * names weights on an endpoint that was already chosen - so it is editable where it is most
 * often the one thing standing between a user and a working second engine. See ADR-0004.
 */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    baseUrl: z<string, string, "defined">;
    model: z<string, string, "volatile-defined">;
    credentialRef: z<string, string, "defined">;
    language: z<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
    requestTimeoutMs: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    baseUrl: z<string, string, "defined">;
    model: z<string, string, "volatile-defined">;
    credentialRef: z<string, string, "defined">;
    language: z<"auto" | "zh" | "en", "auto" | "zh" | "en", "volatile-defined">;
    requestTimeoutMs: z<number, number, "volatile-defined">;
}>>, "plain">;
/** Runtime values the Loader validated from {@link Config}. */
export interface SpeechRailInputConfig {
    /** Loopback SpeechRail base URL ending in `/v1`. */
    baseUrl: string;
    /** Optional explicit model id; empty lets the service choose. */
    model: Volatile<string>;
    /** Credential reference resolved for every operation; empty means the endpoint needs none. */
    credentialRef: string;
    /** Volatile language hint handle; read it through {@link readConfig}. */
    language: Volatile<SpeechRailLanguageMode>;
    /** Volatile request budget handle; read it through {@link readConfig}. */
    requestTimeoutMs: Volatile<number>;
}
/** Plain values unwrapped from {@link SpeechRailInputConfig}. */
export interface SpeechRailInputConfigValues {
    /** Loopback SpeechRail base URL ending in `/v1`. */
    baseUrl: string;
    /** Optional explicit model id; empty lets the service choose. */
    model: string;
    /** Credential reference resolved for every operation; empty means the endpoint needs none. */
    credentialRef: string;
    /** Language hint, or `auto` to omit it. */
    language: SpeechRailLanguageMode;
    /** One request budget in milliseconds. */
    requestTimeoutMs: number;
}
/**
 * Unwrap a Loader-parsed configuration into plain values.
 *
 * Volatile fields arrive as `{ get() }` handles; reading them as plain strings or
 * numbers throws at runtime while still typechecking, which is exactly the failure
 * this function exists to prevent. `tests/config.host.spec.ts` drives the real
 * schema through it.
 * @param config - configuration as the Loader parsed it.
 * @returns the plain values for one operation.
 */
export declare function readConfig(config: SpeechRailInputConfig): SpeechRailInputConfigValues;
//# sourceMappingURL=config.d.ts.map