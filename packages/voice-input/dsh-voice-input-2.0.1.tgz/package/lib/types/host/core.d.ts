/**
 * Single-in-flight transcription engine, independent of Cordis and of the transport.
 *
 * Two invariants shape this file:
 * 1. The gate is claimed synchronously, before the first `await`, so two concurrent
 *    attempts can never both upload.
 * 2. A request byte is only written after the operation is recorded durably, so a
 *    reload can always tell the user that an outcome is unproven.
 * @module dsh-voice-input/host/core
 */
import { type SpeechRailAcknowledgeRequest, type SpeechRailAcknowledgeResult, type SpeechRailCheckResult, type SpeechRailConfigureRequest, type SpeechRailConfigureResult, type SpeechRailFailure, type SpeechRailInputStatus, type SpeechRailLanguageMode, type SpeechRailLimits, type SpeechRailTranscribeRequest, type SpeechRailTranscriptionResult } from '../contracts.ts';
import { type EndpointRefusal } from './endpoint.ts';
import type { PendingJournal } from './journal.ts';
import type { ProbeOutcome, TranscribeOutcome } from './http.ts';
/** Effective configuration for one operation, read fresh so volatile updates apply. */
export interface ResolvedConfig {
    /**
     * Normalized loopback base URL, or an empty string when the endpoint is refused.
     * This is the only URL projection that may cross the Remote boundary, so any
     * userinfo an operator typed never reaches the client.
     */
    readonly baseUrl: string;
    /** Why the endpoint is unusable, or null. */
    readonly endpointRefusal: EndpointRefusal | null;
    /** Optional explicit model id; empty means the service chooses. */
    readonly model: string;
    /** Credential reference resolved for every operation. */
    readonly credentialRef: string;
    /** Configured language mode. */
    readonly language: SpeechRailLanguageMode;
    /** One request budget in milliseconds. */
    readonly requestTimeoutMs: number;
}
/**
 * What this configuration says about the Authorization header.
 *
 * An empty reference is a deliberate "this endpoint needs none", and it must stay distinguishable
 * from a reference that resolves to nothing: one is a working setup and the other is a typo in a
 * reference name. Only the second is refused. See ADR-0003.
 */
export type ResolvedAuth = {
    readonly kind: 'none';
} | {
    readonly kind: 'secret';
    readonly value: string;
} | {
    readonly kind: 'missing';
};
/** Transport and platform seams the engine depends on. */
export interface CoreDependencies {
    /** Current time. */
    readonly now: () => Date;
    /** Read the effective configuration. */
    readonly config: () => ResolvedConfig;
    /** Resolve a credential reference to a non-empty secret, or null. */
    readonly resolveCredential: (ref: string) => Promise<string | null>;
    /** Durable pending-operation journal. */
    readonly journal: PendingJournal;
    /** Upload one recording. */
    readonly transcribe: (options: {
        readonly baseUrl: string;
        readonly model: string;
        readonly language: string | null;
        readonly credential: string | null;
        readonly audio: Uint8Array;
        readonly timeoutMs: number;
        readonly signal?: AbortSignal | undefined;
    }) => Promise<TranscribeOutcome>;
    /** Probe the capability snapshot. */
    readonly probe: (options: {
        readonly baseUrl: string;
        readonly credential: string | null;
        readonly previousLimits?: SpeechRailLimits | null;
    }) => Promise<ProbeOutcome>;
    /** Current settings revision for this entry, or null when Settings is unavailable. */
    readonly settingsRevision: () => number | null;
    /** Persist the editable subset of this entry. */
    readonly writeSettings: (patch: {
        readonly language: SpeechRailLanguageMode;
        readonly requestTimeoutMs: number;
        readonly model: string;
    }, expectedRevision: number) => Promise<'ok' | 'conflict' | 'failed'>;
}
/** One parsed payload, or the failure that refuses it. */
export type ParseResult<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly failure: SpeechRailFailure;
};
/**
 * Parse one transcription payload.
 * @param text - JSON carrier text.
 * @returns the validated request, or a refusal.
 */
export declare function parseTranscribeRequest(text: string): ParseResult<SpeechRailTranscribeRequest>;
/**
 * Parse one configuration payload.
 * @param text - JSON carrier text.
 * @returns the validated request, or a refusal.
 */
export declare function parseConfigureRequest(text: string): ParseResult<SpeechRailConfigureRequest>;
/**
 * Parse one acknowledgement payload.
 * @param text - JSON carrier text.
 * @returns the validated request, or a refusal.
 */
export declare function parseAcknowledgeRequest(text: string): ParseResult<SpeechRailAcknowledgeRequest>;
/** The engine that owns the gate, the cache and the operation lifecycle. */
export declare class SpeechRailInputCore {
    private readonly deps;
    private unprovenFailure;
    private gateState;
    private pendingOperationId;
    private capabilities;
    private checkedAt;
    /** The single probe in flight, if any; see `check()`. */
    private checkInFlight;
    /**
     * Whether the last journal read failed. It distinguishes "this host could not read
     * its medium" from "an upload's outcome is genuinely unproven", which must not be
     * reported as the same thing.
     */
    private journalUnreadable;
    constructor(deps: CoreDependencies);
    /**
     * Read the journal before the service becomes reachable.
     *
     * A reload must not present an unproven earlier upload as "nothing happened".
     * @returns after the gate reflects the durable record.
     */
    restore(): Promise<void>;
    /**
     * Re-read the journal after an unreadable medium, adopting whatever it now reports.
     * @returns after the gate reflects the readable record, if any.
     */
    private reopenJournal;
    /**
     * Decide what the next request carries.
     *
     * An explicitly empty reference means the endpoint needs no credential, so nothing is resolved and
     * nothing is refused; a reference that is configured but resolves to nothing is a configuration
     * error and still refuses with `not-configured`.
     * @param config - effective configuration.
     * @returns the auth state the wire and the reported status both read.
     */
    private resolveAuth;
    /**
     * The language hint the next upload will carry, or null when none will.
     *
     * `auto` never sends one, and a language the snapshot in force refused to admit is withheld
     * rather than guessed. This is the single source of truth for both the wire and the reported
     * state, so no caller can be told about a hint that will not travel.
     */
    private effectiveLanguageHint;
    /**
     * Snapshot everything the UI renders.
     * @returns the current status, including whether the credential is configured.
     */
    status(): Promise<SpeechRailInputStatus>;
    /**
     * Probe the service and refresh the capability cache.
     *
     * A probe never changes the gate: a reachable service proves nothing about an
     * earlier upload whose outcome is still unproven.
     * @returns what the probe observed.
     */
    check(): Promise<SpeechRailCheckResult>;
    private probeOnce;
    /**
     * Persist the editable configuration after a revision check.
     * @param text - JSON carrier text.
     * @returns the new revision, or a localized-code failure.
     */
    configure(text: string): Promise<SpeechRailConfigureResult>;
    /**
     * Claim the gate synchronously; this must run before any `await`.
     * @param operationId - operation claiming the gate.
     * @returns whether the claim succeeded, and why it did not.
     */
    private claim;
    /**
     * Release the gate after a proven outcome, keeping it closed when the journal cannot.
     * @param operationId - operation that owns the gate.
     * @returns after the gate and journal agree.
     */
    private settleKnown;
    /**
     * Close the gate because the remote outcome could not be proven.
     * @param operationId - operation whose outcome is unproven.
     * @returns after the durable record and the gate agree.
     */
    private adoptUnknown;
    /**
     * Upload one recording and return its transcript.
     * @param text - JSON carrier text of a {@link SpeechRailTranscribeRequest}.
     * @param signal - caller cancellation; it never replays or resumes the upload.
     * @returns the transcript, or a sanitized failure.
     */
    transcribe(text: string, signal?: AbortSignal | undefined): Promise<SpeechRailTranscriptionResult>;
    /** Finish one claimed operation, from validation to settlement. */
    private run;
    /**
     * Clear an unproven outcome that the user has explicitly acknowledged.
     * @param text - JSON carrier text of a {@link SpeechRailAcknowledgeRequest}.
     * @returns the remaining pending operation, or a refusal.
     */
    acknowledgeUnknown(text: string): Promise<SpeechRailAcknowledgeResult>;
}
//# sourceMappingURL=core.d.ts.map