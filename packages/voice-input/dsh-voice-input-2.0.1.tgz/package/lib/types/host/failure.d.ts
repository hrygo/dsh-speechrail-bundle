/**
 * Sanitized failure construction: the only shape an error may take on the wire.
 * @module dsh-voice-input/host/failure
 */
import type { SpeechRailFailure, SpeechRailFailureCode, SpeechRailOutcome } from '../contracts.ts';
/**
 * Build one sanitized failure.
 * @param code - closed failure code.
 * @param options - HTTP status, server request id and outcome override.
 * @returns a failure carrying no response body, path, secret or transcript text.
 */
export declare function failure(code: SpeechRailFailureCode, options?: {
    readonly httpStatus?: number | null;
    readonly requestId?: string | null;
    readonly outcome?: SpeechRailOutcome;
}): SpeechRailFailure;
/**
 * Build a failure whose remote outcome could not be proven, so the gate must stay closed
 * until the user acknowledges it.
 * @param code - closed failure code.
 * @param options - HTTP status and server request id.
 * @returns a failure with `outcome: 'unknown'`.
 */
export declare function unknownFailure(code: SpeechRailFailureCode, options?: {
    readonly httpStatus?: number | null;
    readonly requestId?: string | null;
}): SpeechRailFailure;
/**
 * Keep a server request id only when it looks like one: bounded, printable, no separators.
 * @param value - candidate id from an untrusted body or header.
 * @returns the id, or null when it is absent or implausible.
 */
export declare function sanitizeRequestId(value: string | null): string | null;
/**
 * Reduce an untrusted reason string to a short diagnostic token.
 * @param value - candidate reason from a capability snapshot.
 * @returns the token, or null when it is absent or implausible.
 */
export declare function sanitizeReason(value: unknown): string | null;
/**
 * Extract only the non-sensitive fields of a SpeechRail error body.
 * @param body - decoded JSON value of a failed response.
 * @returns the server request id, its error code, and declared retryability.
 */
export declare function readErrorEnvelope(body: unknown): {
    readonly requestId: string | null;
    readonly declaredCode: string | null;
    readonly declaredRetryable: boolean | null;
};
/**
 * Whether an answered status proves the service did not process the upload.
 *
 * Only the service refusing the request itself proves that: 4xx, except 408 Request Timeout. A 5xx
 * may be a gateway timing out while an upstream worker is still transcribing (504 says exactly
 * that), a 3xx tells the client to look elsewhere without establishing anything about the bytes, and
 * a 2xx that is not 200 - 202 Accepted above all - can mean the work is explicitly still running.
 * Those outcomes stay unproven, so the pending journal is kept and the gate keeps asking.
 *
 * This is the only rule that decides it; the upload path must not grow a second one.
 *
 * @param status - response status code that reached the client.
 * @returns whether the upload provably was not processed.
 */
export declare function provesNotProcessed(status: number): boolean;
/**
 * Map an HTTP status to the closed failure vocabulary.
 * @param status - response status code.
 * @param declaredCode - server error code, inspected only for model-specific refusals.
 * @param requestId - sanitized server request id.
 * @param declaredRetryable - server-declared retryability.
 * @returns the sanitized failure.
 */
export declare function failureForStatus(status: number, declaredCode: string | null, requestId: string | null, declaredRetryable: boolean | null): SpeechRailFailure;
//# sourceMappingURL=failure.d.ts.map